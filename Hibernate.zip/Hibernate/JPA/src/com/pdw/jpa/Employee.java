package com.pdw.jpa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="JPATable")
public class Employee {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO, generator="a")
    @SequenceGenerator(name="a",sequenceName="seq")
    
    @Column(name="eid", length=20)
    
    private int empid;
    @Column(name="ename", length=20)
    private String empname;
    @Column(name="esal", length=20)
    private int empsal;
    public Employee(int empid, String empname, int empsal) {
        super();
        this.empid = empid;
        this.empname = empname;
        this.empsal = empsal;
    }
    public Employee()
    {
    	
    }
    
    public int getEmpid() {
        return empid;
    }
    public void setEmpid(int empid) {
        this.empid = empid;
    }
    public String getEmpname() {
        return empname;
    }
    public void setEmpname(String empname) {
        this.empname = empname;
    }
    public int getEmpsal() {
        return empsal;
    }
    public void setEmpsal(int empsal) {
        this.empsal = empsal;
    }
    
    @Override
    public String toString() {
        return "Employee [empid=" + empid + ", empname=" + empname + ", empsal=" + empsal + "]";
    }
    
    
    
}
 





