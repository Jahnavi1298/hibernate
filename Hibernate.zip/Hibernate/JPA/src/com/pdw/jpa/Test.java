package com.pdw.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class Test {
    public static void main(String args[]) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("a");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        //Employee e = new Employee(128,"Janu",10000);
        Employee e=new Employee();
        e.setEmpname("Janu");
        e.setEmpsal(10000);
        em.persist(e);
        em.getTransaction().commit();
        System.out.println("inserted");
        em.close();
        emf.close();
    }


}



