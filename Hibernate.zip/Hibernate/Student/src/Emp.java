
   
public class Emp {
private int eid;
private int esal;
private String ename;
public Emp(int empid, int salary, String empname) {
    super();
    this.eid = empid;
    this.esal = salary;
    this.ename = empname;
}



public Emp() {
	super();
	// TODO Auto-generated constructor stub
}



public int getEid() {
    return eid;
}


public void setEid(int eid) {
    this.eid = eid;
}


public int getEsal() {
    return esal;
}


public void setEsal(int esal) {
    this.esal = esal;
}


public String getEname() {
    return ename;
}


public void setEname(String ename) {
    this.ename = ename;
}


@Override
public String toString() {
    return "Emp [empid=" + eid + ", salary=" + esal + ", empname=" + ename + "]";
}


}
 










