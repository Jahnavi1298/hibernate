
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {
    public static void main(String args[]) {
        Configuration cfg=new Configuration();
        cfg.configure();
        
        SessionFactory factory=cfg.buildSessionFactory();
        Session session=factory.openSession();
        Object o=session.get(Emp.class, new Integer(124));
        Emp e=(Emp)o;
        e.setEname("Uma");
        e.setEsal(100000);
        session.delete(e);
        //Emp e=(Emp) session.get(Emp.class,123);
        //System.out.println(e);
        Transaction tran=session.beginTransaction();
//        Emp emp=new Emp(124,20000,"Janu");
//        session.save(emp);
        tran.commit();
        session.close();
        factory.close();
        
    }


}
 




